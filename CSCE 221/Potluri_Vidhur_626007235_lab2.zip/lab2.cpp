#include <iostream>
#include <stdlib.h> 
using namespace std;

// Question 1
class point{
private:
	int a;
	int b;
public:
	point(){
		cout << "Constructor was called" << endl;
		a = rand()%99 + 1;
		b = rand()%99 + 1;
	};
	point(int x, int y): a(x), b(y){}; 
	void print(){
	 	
		cout << "(" << a << ", " << b << ")" << endl;
	};
	virtual ~point() {
		cout << "Destructor was called" << endl;
	}
};

int main()
{
	//stack - question 2
	cout << endl << "Question 2" << endl;
	point p[5];
	for (int i = 0; i <= 4; i++)
		p[i].print(); 
	
	//heap - question 3 
	cout << endl << "Question 3" << endl;
	point *ps = new point[10];
	for (int i = 0; i <= 9; i++)
		ps[i].print();	
	delete[] ps;	


}



