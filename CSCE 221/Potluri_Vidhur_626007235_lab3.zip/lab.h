#include <cmath>
using namespace std;
//Class template - question 1
template <class T, int sz>

class Point{
private:
	T arr[sz];

public:
	// Constructor
	Point(){
		cout << "Constructor was called" << endl;
	};
	//Destructor - although not needed
	~Point() {};

	//setPoint function
	void setPoint(T pt, int i){
		arr[i] = pt;
	}

	// returns the size of the array
	int getSize(){
		return sz;
	}

	T getPoint(int i){
		return arr[i]; 
	}

	void print() {
		cout << "Debugging" << endl;
		for (int i = 0; i < sz; i++){
			if (i < sz - 1){
				cout << arr[i] << ",";
			}
			else{
				cout << arr[i] << endl;
			}
		}
	};
};

// Function template - Question 2
template <class T>

double edistance(T pt1, T pt2){
	double sum = 0 ;
	for(int i = 0; i < pt1.getSize(); i++)
	{
		sum += pow(pt1.getPoint(i) -pt2.getPoint(i), 2);
	}
	return sqrt(sum);		
}



