#include <iostream>
#include "lab.h"
#include <stdlib.h>
#include <cmath>
using namespace std;

int main() {
	srand(time(NULL)); // To generate random numbers each time the program runs.
	
	// 3D double type points
	Point<double, 3> x;
	for (int i = 0; i < x.getSize(); i++)
	{
		x.setPoint(rand()%9 + 1,i); // random double type number
	}
	x.print();

	Point<double, 3> y;
	for (int i = 0; i < y.getSize(); i++)
	{
		y.setPoint(rand()%9 + 1,i); // random double type number
	}	
	y.print();

	cout << "Euclidian distance: " << edistance(x,y) << endl;;

	// 2D integer type points
	Point<int, 2> a;
	for (int i = 0; i < a.getSize(); i++)
	{
		a.setPoint(rand()%9 + 1,i); // random integer type number
	}
	a.print();

	Point<int, 2> b;
	for (int i = 0; i < b.getSize(); i++)
	{
		b.setPoint(rand()%9 + 1,i); // random integer type number
	}	
	b.print();
	cout << "Euclidian distance: " << edistance(a,b) << endl;;



}
