#include <iostream>
using namespace std;

struct point{
	float x;
	float y;
	point():x(0),y(0){};
	point(float a, float b): x(a), y(b) {};
	point operator+(const point& q){
		point z;
		z.x = x + q.x;
		z.y = y + q.y;
	}
};

class Shape{
protected:
	point s;
public:
	virtual void print() = 0;
	Shape (point x) : s(x) {};
};

class Circle: public Shape{
	float radius;
public:
	Circle(point u, float r): Shape(u),radius(r) {};
	virtual void print(){
		cout << "Circle at position " << s.x << "," << s.y << " with radius " << radius << endl;
	}
};

class Square: public Shape{
	float side;
public:
	Square(point u, float a): Shape(u), side(a) {};
	virtual void print(){
		cout << "Square at position " << s.x << "," << s.y << " with side length " << side << endl;
	}
};

int main()
{
	point x(3, 2);
	Square m(x, 5);

	point y(-5, 6);
	Circle n(y, 4);

	m.print();
	n.print();

	return 0;
}